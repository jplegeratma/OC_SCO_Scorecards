SET pause OFF
SET feedback ON
SET TIME ON
SET timing ON

WHENEVER SQLERROR EXIT failure ROLLBACK

DECLARE
   CURSOR c1 IS
	SELECT pqprov.pq_prov_seq as pqseq, fy_end, SUBMITTAL_DT as filingdt
	FROM 	
	  (select filing.submittal_dt, 
	          tracking.* 
	   from (select ufr_filing_period, 
	                ciw_tin_fein, 
	                min(submittal_dt) as submittal_dt, 
	                min(filing_type) as filing_type
                 from pd_ufr_filing 
                 where filing_type not in (4, 5, 7)
                 group by ufr_filing_period, ciw_tin_fein
           ) filing, 
	   pd_ufr_tracking tracking
	   where tracking.ciw_tin_fein = filing.ciw_tin_fein (+) and 
	         tracking.ufr_filing_period = filing.ufr_filing_period (+) ) filtrac,        
	   (select prov.*, 
	           const.cur_fy_year as fy_year, 
	           pq.* 
	    from pd_pos_prov prov, 
	         pq_pos_prov pq, 
	         pq_constants const
	    where pq.pdm_provider_seq = prov.pdm_provider_seq and 
	          pq.pq_year = const.pq_year) pqprov
	WHERE 
	    pqprov.fy_year = filtrac.ufr_filing_period (+) and
	    pqprov.ciw_tin_fein = filtrac.ciw_tin_fein (+);
BEGIN
   FOR ufr IN c1 LOOP  -- process each row one at a time
   BEGIN
         INSERT INTO pq_prov_qual (PQ_PROV_SEQ, QUAL_STATUS, FINSUB_TYPE, IAUD_OPIN,
                                   UFR_FILING_PERIOD_REV,
                                   DT_UFR_RECBY_OSD)
         VALUES (ufr.pqseq, 'Pending', 'N/A', 'N/A', ufr.fy_end, ufr.filingdt);
         EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN   -- account already exists
	    UPDATE pq_prov_qual SET
		 UFR_FILING_PERIOD_REV = ufr.fy_end,
		 DT_UFR_RECBY_OSD = ufr.filingdt
	    WHERE
		 pq_prov_seq = ufr.pqseq;
   END;
   END LOOP;
   
END;
/