ls -latr
exit
ls -latr
cat .bash_profile
cp ../jpleger/.bash_profile .
ls -latr
less .bash_profile 
ls -latr ../jpleger
cp ../jpleger/.dq_profile .
cp -R ../jpleger/dqs .
ls -latr
cat .dq_profile
grep -i jpleger .bash_profile
vi .bash_profile
vi .dq_profile
cd dqs
ls -latr
cp application.sh application.sh.20201015
vi application.sh
exit
clear
ls -latr
vi .bash_profile
vi .dq_profile 
cd dqs/scheduling/scripts/
ls -latr
rm -rf backup*
ls -latr
mkdir hold
mv runDQ_ANOMALY_step41.sh hold
mv runDQ_ANOMALY.sh hold
mv DQ_ANOMALY.sh hold
mv runDQ_SCORECARD.sh hold
mv DQ_SCORECARD.sh hold
cd hold
ls
cd ..
ls -latr
rm *
ls -latr
cd archive
ls
rm *
cd ..
rmdir archive
cd hold
mv * ..
ls
cd ..
rmdir hold
ls -latr
exir
exit
groups
exit
clear
ls -latr
cd dqs/scheduling/scripts/
ls -latr
cd ..
cd sql/ddl/
ls
cat init_params.sql
cd 
cd dqs/scheduling/scripts/
ls -latr

pwd
./runDQ_ANOMALY.sh
tail -f ../logs/DQ_ANOMALY101620122228.sh.log 
less ../logs/DQ_ANOMALY101620122228.sh.log 
exit
cd dqs/
ls -latr
cp application.sh application.sh.20201016
vi application.sh
clear
cd scheduling/scripts/
ls -latr
clear
pwd
rm ../logs/*
ls -latr
./runDQ_ANOMALY.sh 
tail -f ../logs/DQ_ANOMALY101620123358.sh.log 
clear
less ../logs/DQ_ANOMALY101620123358.sh.log 
ls -latr
top
clear
ls -latr
vi DQ_ANOMALY.sh
exit
cd /dq/sql/ddl
cd /dqs/sql/ddl
pwd
cd dqs/sql/ddl/
ls -latr
mv init_params.sql init_params.sql.20201019
cp /tmp/init_params.sql .
cd ..
cd scheduling/scripts/
ls -latr
mv DQ_ANOMALY.sh DQ_ANOMALY.sh.20201019
mv runDQ_ANOMALY.sh runDQ_ANOMALY.sh.20201019
cp /tmp/runDQ_ANOMALY.sh .
cp /tmp/DQ_ANOMALY.sh .
cd /tmp
ls -latr
cat init_params.sql
exit
cd dqs/scheduling/scripts/
rm ../logs/*
./runDQ_ANOMALY.sh 
less ../logs/DQ_ANOMALY102020092423.sh.log 
tail -f ../logs/DQ_ANOMALY102020092423.sh.log 
clear
less ../logs/DQ_ANOMALY102020092423.sh.log 
exit
cd dqs/sql/dbupdate/
ls -latr
cd ..
ls -latr
cd scheduling/scripts/
ls -latr
less DQ_ANOMALY.sh
cd ../../sql/dbupdate/
ls -latr
cat DA_PURGE.sql
clear
exit
cd dqs/scheduling/scripts/
rm ../logs/*
./runDQ_ANOMALY.sh 
less ../logs/DQ_ANOMALY102220121511.sh.log 
clear
tail -f ../logs/DQ_ANOMALY102220121511.sh.log 
cd dqs/sql/dbupdate/
cp /tmp/DA_PURGE.sql .
cp /tmp/DA_STATS.sql .
cd ../ddl
cp /tmp/init_params.sql .
ls -latr
cat init_params.sql
clear
ls -latr
rm init_params.sql.2020101*
ls -latr
rm *.log
cp /tmp/DA_TABLES.sql .
cp /tmp/DA_INDEXES.sql .
cp /tmp/DA_GRANTS.sql .
cp /tmp/DA_VIEWS.sql .
ls -latr
cd ../../scheduling/scripts/
ls -latr
cp DQ_ANOMALY.sh DQ_ANOMALY.sh.20201029-1
cp /tmp/DQ_ANOMALY.sh .
ls -latr
top
clear
ls -latr
rm ../logs/*
./runDQ_ANOMALY.sh 
tail -f ../logs/DQ_ANOMALY102920140348.sh.log 
clear
top
less ../logs/DQ_ANOMALY102920140348.sh.log 
clear
top
pwd
ls -latr
cp DQ_ANOMALY.sh DQ_ANOMALY.sh.20201029-2
rm DQ_ANOMALY.sh
cp /tmp/DQ_ANOMALY.sh .
ls -latr
diff DQ_ANOMALY.sh DQ_ANOMALY.sh.20201029-2
clear
top
exit
cd dqs/scheduling/scripts/
ls -latr
rm ../logs/*
./runDQ_ANOMALY.sh 
tail -f ../logs/DQ_ANOMALY103020093858.sh.log 
less ../logs/DQ_ANOMALY103020093858.sh.log 
tail -f ../logs/DQ_ANOMALY103020093858.sh.log 
less ../logs/DQ_ANOMALY103020093858.sh.log 
top
clear
grep 'is done' DQ_ANOMALY.sh
less DQ_ANOMALY.sh
clear
ls -latr
cat runDQ_ANOMALY.sh
grep send_mail DQ_ANOMALY.sh
grep send_email DQ_ANOMALY.sh
clear
top
groups
exit
cd dqs/sql/ddl/
ls -latr
cat DA_GRANTS.sql
exit
cd dqs
cd sql
cd ddl
ls -latr
cd ..
ls -latr
cd dbupdate/
ls -latr
cd ../..
ls -latr
cat application.sh
cd scheduling/
ls -latr
cd scripts/
ls -latr
cp /tmp/DQ_SCORECARD.sh .
cp /tmp/runDQ_SCORECARD.sh .
ls -latr
cat runDQ_SCORECARD.sh 
cp runDQ_SCORECARD.sh.JUN2018_SEP2018
cp runDQ_SCORECARD.sh runDQ_SCORECARD.sh.JUN2018_SEP2018
cp /tmp/runDQ_SCORECARD.sh.MAR2018_JUN2018 .
cp /tmp/runDQ_SCORECARD.sh.MAR2018_JUN2018 runDQ_SCORECARD.sh
clear
ls -latr
clear
ls -latr
rm ../logs/*
cat runDQ_SCORECARD.sh
./runDQ_SCORECARD.sh
tail -f ../logs/DQ_SCORECARD121120110454.sh.log 
cd dqs/scheduling/scripts/
clear
ls -latr
cp runDQ_SCORECARD.sh.MAR2018_JUN2018 runDQ_SCORECARD.sh.APR2018_JUL2018
cp runDQ_SCORECARD.sh.MAR2018_JUN2018 runDQ_SCORECARD.sh.MAY2018_AUG2018
vi runDQ_SCORECARD.sh.APR2018_JUL2018
vi runDQ_SCORECARD.sh.MAY2018_AUG2018 
clear
ls -latr
cp runDQ_SCORECARD.sh.APR2018_JUL2018 runDQ_SCORECARD.sh
rm ../logs/*
./runDQ_SCORECARD.sh
tail -f ../logs/DQ_SCORECARD121120154417.sh.log 

ls -latr
cp runDQ_SCORECARD.sh.MAY2018_AUG2018 runDQ_SCORECARD.sh
rm ../logs/*
./runDQ_SCORECARD.sh
tail -f ../logs/DQ_SCORECARD121120155456.sh.log 
cp runDQ_SCORECARD.sh.JUN2018_SEP2018 runDQ_SCORECARD.sh
./runDQ_SCORECARD.sh
tail -f ../logs/DQ_SCORECARD1211201
ls -latr ../logs
tail -f ../logs/DQ_SCORECARD121120160626.sh.log 
top
exit
cd dqs/scheduling/scripts/
clear
ls -latr
cp /tmp/DQ_ANOMALY_v1_9.sh .
cp /tmp/runDQ_ANOMALY_v1_9.sh .
diff runDQ_ANOMALY_v1_9.sh runDQ_ANOMALY.sh
clear
ls -latr
rm ../logs/*
./runDQ_ANOMALY_v1_9.sh
tail -f ../logs/DQ_ANOMALY011121150808.sh.log 
ls -latr
chmod 777 DQ_ANOMALY_v1_9.sh 
clear
rm ../logs/*
./runDQ_ANOMALY_v1_9.sh
tail -f ../logs/DQ_ANOMALY011121150808.sh.log 
tail -f ../logs/DQ_ANOMALY011121151207.sh.log 
top
clear
rm ../logs/*
./runDQ_ANOMALY_v1_9.sh
tail -f ../logs/DQ_ANOMALY011121160942.sh.log 
top
clear
rm ../logs/*
./runDQ_ANOMALY_v1_9.sh
tail -f ../logs/DQ_ANOMALY011121164022.sh.log 
top
exit
cd dqs/scheduling/scripts/
ls -latr
rm ../logs/*
./runDQ_ANOMALY_v1_9.sh
tail -f ../logs/DQ_
tail -f ../logs/DQ_ANOMALY011221132938.sh.log 
top
exit
cd dqs/scheduling/scripts/
clear
ls -latr
top
exit
cd dqs/scheduling/scripts/
clear
ls -latr
rm ../logs/*
./runDQ_ANOMALY_v1_9.sh
tail -f ../logs/DQ_ANOMALY011421144510.sh.log 
clear
top
exit
