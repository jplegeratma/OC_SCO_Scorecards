SET pause OFF
SET echo ON
SET feedback ON
SET TIME ON
SET timing ON

WHENEVER SQLERROR EXIT failure ROLLBACK

TRUNCATE TABLE PD_CONTRACT_DETAIL
/
TRUNCATE TABLE PD_CONTRACT_SUMMARY
/
TRUNCATE TABLE PD_CONTRACT_TOTAL
/
TRUNCATE TABLE PD_ENCUMBRANCES_NON_POS
/
TRUNCATE TABLE PD_ENCUMBRANCES_NON_EHS
/
TRUNCATE TABLE PD_SERVICES_PROVIDED
/
TRUNCATE TABLE PD_ENCUMB_LAST_LOAD_DT
/
TRUNCATE TABLE PD_CIW_STD_FORMS
/
TRUNCATE TABLE PD_PREQUAL_RAM
/

INSERT INTO PD_CONTRACT_DETAIL  (
SELECT
   en.budget_fiscal_year,
   en.department,
   en.activity,
   en.activity_name,
   en.doc_identifier,
   en."OBJECT" object_code,
   SUM (en.actg_line_amount) contract_amt,
   SUM (en.ref_line_amount) closed_contract_amt,
   (SUM (en.actg_line_amount) - SUM (en.ref_line_amount)) encumb_open_amt,
   MAX (ROWNUM) AS rnum_seq,
   prov.org_id
FROM m_pr_encumbrance_detail en, PD_POS_PROV prov
WHERE en.budget_fiscal_year = 2016
     AND en.tin = prov.ciw_tin_fein
     AND en."OBJECT" IN ('M1M', 'M03', 'M04', 'M2M', 'MM3')
     AND en.cabinet = '45'
	AND en.event_type in ('PR05', 'PR51')
	AND en.DOC_CODE in ('CT', 'RPO')
GROUP BY prov.org_id,
         en.budget_fiscal_year,
         en.department,
         en.activity,
         en.activity_name,
         en.doc_identifier,
         en."OBJECT")
/

INSERT INTO PD_CONTRACT_DETAIL  (
SELECT
   en.budget_fiscal_year,
   en.department,
   en.activity,
   en.activity_name,
   en.doc_identifier,
   en."OBJECT" object_code,
   SUM (en.actg_line_amount) contract_amt,
   SUM (en.ref_line_amount) closed_contract_amt,
   (SUM (en.actg_line_amount) - SUM (en.ref_line_amount)) encumb_open_amt,
   MAX (ROWNUM) AS rnum_seq,
   prov.org_id
FROM m_pr_encumbrance_detail en, PD_POS_PROV prov
WHERE en.budget_fiscal_year = 2016
     AND en.tin = prov.ciw_tin_fein
     AND en."OBJECT" IN ('M03','MM3')
     AND en.cabinet = '92'
     AND en.department = 'OCD'
	AND en.event_type in ('PR05', 'PR51')
	AND en.DOC_CODE in ('CT', 'RPO')
GROUP BY prov.org_id,
         en.budget_fiscal_year,
         en.department,
         en.activity,
         en.activity_name,
         en.doc_identifier,
         en."OBJECT")
/

INSERT INTO PD_CONTRACT_SUMMARY  (
SELECT
  en.department,
   SUM (en.actg_line_amount) contract_amt,
   SUM (en.ref_line_amount) closed_contract_amt,
   (SUM (en.actg_line_amount) - SUM (en.ref_line_amount)) encumb_open_amt,
 MAX (ROWNUM) AS rnum_seq,
 prov.org_id,
 en.budget_fiscal_year
FROM m_pr_encumbrance_detail en, PD_POS_PROV prov
WHERE en.budget_fiscal_year = 2016
     AND en.tin = prov.ciw_tin_fein
     AND en."OBJECT" IN ('M1M', 'M03', 'M04', 'M2M', 'MM3')
     AND en.cabinet = '45'
	AND en.event_type in ('PR05', 'PR51')
	AND en.DOC_CODE in ('CT', 'RPO')
GROUP BY prov.org_id, en.department, en.budget_fiscal_year)
/

INSERT INTO PD_CONTRACT_SUMMARY  (
SELECT
  en.department,
   SUM (en.actg_line_amount) contract_amt,
   SUM (en.ref_line_amount) closed_contract_amt,
   (SUM (en.actg_line_amount) - SUM (en.ref_line_amount)) encumb_open_amt,
 MAX (ROWNUM) AS rnum_seq,
 prov.org_id,
 en.budget_fiscal_year
FROM m_pr_encumbrance_detail en, PD_POS_PROV prov
WHERE en.budget_fiscal_year = 2016
     AND en.tin = prov.ciw_tin_fein
     AND en."OBJECT" IN ('M03','MM3')
     AND en.cabinet = '92'
     AND en.department = 'OCD'
	AND en.event_type in ('PR05', 'PR51')
	AND en.DOC_CODE in ('CT', 'RPO')
GROUP BY prov.org_id, en.department, en.budget_fiscal_year)
/


INSERT INTO PD_CONTRACT_TOTAL  (
SELECT
  en.budget_fiscal_year,
  ROUND (SUM (en.actg_line_amount), 2) AS contract_amt,
  ROUND (SUM (en.ref_line_amount), 2) AS closed_contract_amt,
  ROUND ((SUM (en.actg_line_amount) - SUM (en.ref_line_amount)), 2) AS encumb_open_amt,
  MAX (ROWNUM) AS rnum_seq, prov.org_id
FROM m_pr_encumbrance_detail en, PD_POS_PROV prov
WHERE en.budget_fiscal_year = 2016
     AND en.tin = prov.ciw_tin_fein
     AND en."OBJECT" IN ('M1M', 'M03', 'M04', 'M2M', 'MM3')
     AND en.cabinet = '45'
	AND en.event_type in ('PR05', 'PR51')
	AND en.DOC_CODE in ('CT', 'RPO')
GROUP BY prov.org_id, en.budget_fiscal_year)
/

INSERT INTO PD_CONTRACT_TOTAL  (
SELECT
  en.budget_fiscal_year,
  ROUND (SUM (en.actg_line_amount), 2) AS contract_amt,
  ROUND (SUM (en.ref_line_amount), 2) AS closed_contract_amt,
  ROUND ((SUM (en.actg_line_amount) - SUM (en.ref_line_amount)), 2) AS encumb_open_amt,
  MAX (ROWNUM) AS rnum_seq, prov.org_id
FROM m_pr_encumbrance_detail en, PD_POS_PROV prov
WHERE en.budget_fiscal_year = 2016
     AND en.tin = prov.ciw_tin_fein
     AND en."OBJECT" IN ('M03','MM3')
     AND en.cabinet = '92'
     AND en.department = 'OCD'
	AND en.event_type in ('PR05', 'PR51')
	AND en.DOC_CODE in ('CT', 'RPO')
GROUP BY prov.org_id, en.budget_fiscal_year)
/

INSERT INTO PD_ENCUMBRANCES_NON_POS  (
SELECT
  MAX (budget_fiscal_year) AS budget_fiscal_year,
  tin,
  ' ' AS legal_name,
  ' ' AS department,
  SUM (contract_amount) AS contract_amount
FROM
  m_pr_encumbrance_detail
WHERE
  "OBJECT" NOT IN ('M1M', 'M03', 'M04', 'M2M', 'MM3')
GROUP BY tin, budget_fiscal_year)
/

INSERT INTO PD_ENCUMBRANCES_NON_EHS
(SELECT   budget_fiscal_year, tin, ' ' AS legal_name, ' ' AS department,
          SUM (contract_amount) AS contract_amount
     FROM m_pr_encumbrance_detail
    WHERE department NOT IN
             ('DMA',
              'DMH',
              'DMR',
              'DPH',
              'MCD',
              'ORI',
              'OFC',
              'VET',
              'WEL',
              'DSS',
              'OCD',
              'DYS',
              'MCB',
              'MRC',
              'CHE',
              'HLY',
              'ELD',
              'HCF',
              'EHS'
             )
GROUP BY tin, budget_fiscal_year)
/

INSERT INTO PD_SERVICES_PROVIDED  (
SELECT
  MAX(ROWNUM) ROWNUM_SEQ,
  e.department,
  e.TIN,
  e.legal_name,
  e.activity_group,
  e.activity_group_name,
  e.activity_type,
  e.activity_type_name,
  e.activity_class,
  e.activity_class_name,
  e.activity || ' - ' || e.activity_name
FROM
  m_pr_encumbrance_detail e
WHERE
  e.department IN ('DMA' , 'DMH' , 'DMR' , 'DPH' , 'MCD' , 'ORI' , 'OFC' , 'VET' , 'WEL' , 'DSS' , 'DYS' , 'MCB' , 'MRC' , 'CHE' , 'HLY' , 'ELD' , 'HCF' , 'EHS')   AND
  e."OBJECT" IN ('M1M','M03','M04','M2M','MM3')   AND
  TIN IS NOT NULL
GROUP BY e.department, e.TIN, e.legal_name, e.activity_group, e.activity_group_name, e.activity_type, e.activity_type_name, e.activity_class, e.activity_class_name, e.activity || ' - ' || e.activity_name)
/

INSERT INTO PD_SERVICES_PROVIDED  (
SELECT
  MAX(ROWNUM) ROWNUM_SEQ,
  e.department,
  e.TIN,
  e.legal_name,
  e.activity_group,
  e.activity_group_name,
  e.activity_type,
  e.activity_type_name,
  e.activity_class,
  e.activity_class_name,
  e.activity || ' - ' || e.activity_name
FROM
  m_pr_encumbrance_detail e
WHERE
  e.department = 'OCD' 
  AND e."OBJECT" IN ('M03','MM3')  AND
  TIN IS NOT NULL
GROUP BY e.department, e.TIN, e.legal_name, e.activity_group, e.activity_group_name, e.activity_type, e.activity_type_name, e.activity_class, e.activity_class_name, e.activity || ' - ' || e.activity_name)
/


INSERT INTO PD_ENCUMB_LAST_LOAD_DT  (
SELECT
  tin,
  TO_DATE(MAX(SNAPSHOT_DT_TIM_SEQ), 'YYYY/MM/DD')
FROM
  m_pr_encumbrance_detail e
WHERE
  object_class = 'MM'
GROUP BY tin)
/

INSERT INTO PD_CIW_STD_FORMS  (
SELECT
  a1.ciw_legal_name,
  a1.org_id,
  ' ' AS form_name,
  b1.business_type,
  ' ' AS onfile_with,
  'On File With OSD' AS status,
  MAX(b1.cert_start_date) AS updated,
  ' ' AS comments
FROM
  PD_POS_PROV a1,
  PD_CIW_VENDOR_BUS_TYPE b1
WHERE
  UPPER(a1.ciw_legal_name)  = b1.legal_name AND
  b1.business_type_id IN ('TC', 'TCHS')
GROUP BY a1.ciw_legal_name, a1.org_id, b1.business_type)
/

INSERT INTO PD_PREQUAL_RAM  (
SELECT
  b.ciw_tin_fein,
  b.ciw_legal_name,
  SUBSTR (a.ufr_filing_period, 3, 2) AS ufr_filing_period,
  ROUND (a.current_ratio, 2) AS current_ratio,
  ROUND (c.days_in_cash, 2) AS days_in_cash,
  ROUND (d.days_in_working_capital, 2) AS days_in_working_capital,
  ROUND (e.days_in_payables, 2) AS days_in_payables,
  ROUND (f.days_in_receivable, 2) AS days_in_receivable,
  ROUND (g.op_margin, 2) AS op_margin,
  ROUND (h.total_margin, 2) AS total_margin,
  ROUND (j.debt_to_assets, 2) AS debt_to_assets,
  ROUND (k.op_cf_to_cl, 2) AS op_cf_to_cl,
  ROWNUM AS r_seq
FROM
  pd_ufr_ram_current_ratio a,
  PD_POS_PROV b,
  pd_ufr_ram_days_in_cash c,
  pd_ufr_ram_days_in_wc d,
  pd_ufr_ram_days_in_payables e,
  pd_ufr_ram_days_in_receivable f,
  pd_ufr_ram_op_margin g,
  pd_ufr_ram_total_margin h,
  pd_ufr_ram_op_cf_to_cl i,
  pd_ufr_ram_debt_asset j,
  pd_ufr_ram_op_cf_to_cl k
WHERE
  a.ciw_tin_fein = b.ciw_tin_fein       	AND
  b.ciw_tin_fein = c.ciw_tin_fein       	AND
  a.ufr_filing_period = c.ufr_filing_period     AND
  a.ufr_filing_period = d.ufr_filing_period     AND
  d.ciw_tin_fein = b.ciw_tin_fein       	AND
  a.ufr_filing_period = e.ufr_filing_period     AND
  b.ciw_tin_fein = e.ciw_tin_fein       	AND
  b.ciw_tin_fein = f.ciw_tin_fein       	AND
  a.ufr_filing_period = f.ufr_filing_period     AND
  a.ufr_filing_period = g.ufr_filing_period     AND
  b.ciw_tin_fein = g.ciw_tin_fein       	AND
  a.ufr_filing_period = h.ufr_filing_period     AND
  b.ciw_tin_fein = h.ciw_tin_fein       	AND
  a.ufr_filing_period = i.ufr_filing_period     AND
  b.ciw_tin_fein = i.ciw_tin_fein       	AND
  a.ufr_filing_period = j.ufr_filing_period     AND
  b.ciw_tin_fein = j.ciw_tin_fein       	AND
  a.ufr_filing_period = k.ufr_filing_period     AND
  b.ciw_tin_fein = k.ciw_tin_fein
GROUP BY b.ciw_tin_fein, b.ciw_legal_name, a.ufr_filing_period, a.current_assets,
	a.current_liabilities, a.current_ratio, c.days_in_cash, d.days_in_working_capital,
	e.days_in_payables, f.days_in_receivable, g.op_margin, h.total_margin, j.debt_to_assets, k.op_cf_to_cl, ROWNUM)
/

update pd_ufr_tracking set pd_load_dt = sysdate
/
delete from pd_ufr_filing where ufr_filing_period = '2002'
/
delete from pd_ufr_filing where ufr_filing_period = '2003'
/
