SET pause OFF
SET feedback ON
SET TIME ON
SET timing ON

WHENEVER SQLERROR EXIT failure ROLLBACK

DECLARE
   CURSOR c1 IS
      SELECT 
        pqprv.pdm_provider_seq as provseq, 
        pqprv.pq_year as pqyear, 
        cnst.cur_fy_year as fyyear
      FROM 
        pq_pos_prov pqprv, 
        pq_constants cnst 
      WHERE 
        pqprv.pq_year = cnst.pq_year
      MINUS
      SELECT 
        pdm_provider_seq, 
        pq_year, 
        fy_year
      FROM 
        PQ_PROV_FINANCIALS, 
        PQ_CONSTANTS
      WHERE 
        PQ_PROV_FINANCIALS.fy_year = PQ_CONSTANTS.cur_fy_year;



   CURSOR c21 IS
   SELECT 
           b.CURRENT_RATIO as CURRENT_RATIO, 
           b.DAYS_IN_WORKING_CAPITAL as DAYS_IN_WORKING_CAPITAL, 
           b.OP_MARGIN as OP_MARGIN, 
           '20' || b.ufr_filing_period as budget_fiscal_year,
           a.pdm_provider_seq as pdm_provider_seq
   FROM 
      pd_pos_prov a, 
      pd_prequal_ram_v b
    WHERE  
      a.ciw_tin_fein = b.ciw_tin;

   CURSOR c22 IS
   SELECT 
           c.contract_amt as contract_amt,
           c.budget_fiscal_year as budget_fiscal_year,
           a.pdm_provider_seq as pdm_provider_seq
   FROM 
      pd_pos_prov a, 
     (
     SELECT
	dt.budget_fiscal_year, 
	ROUND (SUM (dt.check_amount), 2) AS contract_amt,
	prov.org_id
      FROM m_ap_disbursement_detail dt, PD_POS_PROV prov
      WHERE 
	dt.tin = prov.ciw_tin_fein AND 
	dt."OBJECT" IN ('M03', 'MM3') AND
	dt.cabinet = '45'
      GROUP BY prov.org_id, dt.budget_fiscal_year, dt.tin, dt.cabinet 
      ) c
    WHERE  
      c.org_id = a.org_id;


   CURSOR c3 IS           
   SELECT 
     pqprv.pdm_provider_seq as provseq, 
     pqprv.pq_year as pqyear, 
     cnst.cur_fy_year as fyyear, 
     current_ratio, 
     days_in_working_capital, 
     operating_margin
   FROM 
     pq_pos_prov pqprv, 
     pq_constants cnst, 
     pq_prov_financials fin 
   WHERE 
     pqprv.pq_year = cnst.pq_year and 
     cnst.cur_fy_year = fin.fy_year and
     pqprv.ufr_filerprov_seq = fin.PDM_PROVIDER_SEQ;
      
   CURSOR c4 IS  
   SELECT 
     pdm_provider_seq, 
     prntseq, 
     pqyear, 
     fyyear, 
     orgexp
   FROM pq_pos_prov a, 
      	(SELECT 
      	   pqprv.prnt_provider_seq as prntseq, 
      	   pqprv.pq_year as pqyear, 
      	   fin.fy_year as fyyear, 
      	   sum(fy_exp) as orgexp 
      	 FROM 
      	   pq_pos_prov pqprv, 
      	   pq_constants cnst, 
      	   pq_prov_financials fin 
      	 WHERE 
      	   pqprv.pq_year = cnst.pq_year and 
      	   cnst.cur_fy_year = fin.fy_year and
      	   pqprv.pdm_provider_seq = fin.pdm_provider_seq
      	 GROUP BY pqprv.prnt_provider_seq, fin.fy_year, pqprv.pq_year) b 
   WHERE 
     a.prnt_provider_seq = b.prntseq and 
     a.pq_year = b.pqyear;	  

      
BEGIN
   -- (Step 1) add records for every record in pq_pos_prov
   FOR pq IN c1 LOOP  -- process each row one at a time
       INSERT INTO pq_prov_financials
	     (
	     pq_fnc_seq,
	     fy_year,
	     funding_codes,
	     pdm_provider_seq
	     )
       VALUES 
             (
             seq_pq_fncl.nextval,
             pq.fyyear,
             'M03, MM3',
             pq.provseq
             );
    END LOOP;
    
    -- (Step 21) 
   FOR afr IN c21 LOOP  -- process each row one at a time
    UPDATE pq_prov_financials SET
         current_ratio = afr.current_ratio, 
         days_in_working_capital = afr.days_in_working_capital, 
         operating_margin = afr.op_margin
    WHERE
         fy_year = afr.budget_fiscal_year AND
         pdm_provider_seq = afr.pdm_provider_seq;

   END LOOP;

    -- (Step 22) 
   FOR afr IN c22 LOOP  -- process each row one at a time
    UPDATE pq_prov_financials SET
         fy_exp = afr.contract_amt
    WHERE
         fy_year = afr.budget_fiscal_year AND
         pdm_provider_seq = afr.pdm_provider_seq;

   END LOOP;
   
   -- (Step 3) set same ratios as ufr filer
   FOR bfr IN c3 LOOP  -- process each row one at a time
    UPDATE pq_prov_financials SET
         current_ratio = bfr.current_ratio, 
         days_in_working_capital = bfr.days_in_working_capital, 
         operating_margin = bfr.operating_margin
    WHERE
         fy_year = bfr.fyyear AND
         pdm_provider_seq = bfr.provseq;

   END LOOP;

   -- (Step 4)
   FOR cfr IN c4 LOOP  -- process each row one at a time
    UPDATE pq_prov_financials SET
         org_exp_total = cfr.orgexp 
    WHERE
         fy_year = cfr.fyyear AND
         pdm_provider_seq = cfr.pdm_provider_seq;

   END LOOP;
   
END;
/