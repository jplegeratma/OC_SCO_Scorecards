SET pause OFF
SET feedback ON
SET TIME ON
SET timing ON


WHENEVER SQLERROR EXIT failure ROLLBACK

DECLARE
   CURSOR c1 IS
	SELECT pqqual.pq_prov_seq as pqseq, pqprov.pq_year as pqyear, pqprov.ufr_filer as ufrfiler, pqqual.dt_ufr_recby_osd as filingdt
	FROM pq_pos_prov pqprov, pq_prov_qual pqqual WHERE pqqual.dt_ufr_recby_osd is not null  and pqprov.pq_prov_seq = pqqual.pq_prov_seq and pqprov.pq_year = '2016';
BEGIN
   FOR ufr IN c1 LOOP  -- process each row one at a time
   BEGIN
     IF ufr.ufrfiler = 'E' THEN
	    UPDATE pq_pos_prov SET
		 UFR_FILER = 'Y'
	    WHERE
		 pq_prov_seq = ufr.pqseq;
     END IF;
     IF ufr.ufrfiler = 'N' THEN
	    UPDATE pq_pos_prov SET
		 UFR_FILER = 'Y'
	    WHERE
		 pq_prov_seq = ufr.pqseq;
     END IF;
   END;
   END LOOP;
END;
/
