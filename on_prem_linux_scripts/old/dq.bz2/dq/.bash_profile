# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
	. ~/.bashrc
fi

# User specific environment and startup programs
#.dq_profile

ORACLE_HOME=/u01/oracle/product/11.2.0
export ORACLE_HOME
PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin
LC_ALL=C
export PATH
export LD_LIBRARY_PATH=/usr/local/lib:ORACLE_HOME/lib:
export DQBINHOME=/home/dq/dqs

. $DQBINHOME/scheduling/functions.sh
export INFA_TRUSTSTORE=/informatica/qa/102/PowerCenter/services/shared/security


