#!/bin/bash
# This a generic script that runs a set of jobs sequentially and keeps track of the job stream's state along the way.
# If a step exits with an error, this script exits with an error.  Subsequent executions of this script restart the
# stream at the point of failure (unless all steps executed successfully - in that case the script starts again from
# the top).  State is stored in several files in the /home/pdm/pdms/job_states directory
#
# Usage:
# nohup run_jobs.sh [-q][-b end_step][-e end_step][-o override_file_name] -s <script_name> > <script_name>.log 2>&1 &
#
# Where the array $all_jobs contains a shell command to be executed for each element of the array.
# A non-zero return code causes this script to halt, exiting a non-zero code (failure)
#
# The optional "-q" switch runs nothing, but queries the current state of the job stream and
# reports what has/has not been run.
#
# The "-e" switch allows you to specify after what step the job stream should stop (the default 
# is after the last step).  When -e is used, subsequent executions of the script will start
# after the point at which it was stopped.
#

# Constants

USAGE=$(cat <<EOF

Usage:

 nohup run_jobs.sh [-q][-b begin_step] [-e end_step] [-o override_file_name] \ 
        -s <script_name> > <script_name>.log 2>&1 &

        where <script_name> is the file in cwd that contains the all_jobs definitions
        -q executes nothing but reports on status
        -o override the filename for the .PID and .jobs_run file 
        -e <end_step> runs steps from begin to (and including) end_step
        -b <begin_step> runs steps from begin_step (inclusive) to end
            -b and -e can be combined to run a set of steps
            steps start with step 0
EOF
)

JOB_STATE_DIR=/home/pdm/pdms/job_states

. /home/pdm/pdms/scheduling/functions.sh

if [ $? -gt 0 ]
    then
    echo "Error: ($script_name) cannot execute functions.sh (file not found or not executable)" 1>&2
    exit 1
fi

unset script_name

# check parameters
while getopts "qb:e:s:o:" Option
do
  case $Option in
   b     ) batch_start=$OPTARG;;
   e     ) batch_end=$OPTARG;;
   s     ) script_name=$OPTARG;;
   o     ) override_file_name=$OPTARG;;
   q     ) run_query=1;;
   *     ) echo "Error: (run_jobs.sh) Unknown switch"
        echo "$USAGE"
     exit 1;;
  esac
done
shift $(($OPTIND - 1))

# check for script_name parameter
if [ -z "$script_name" ]
then
 echo "Error: (run_jobs.sh) script name must be passed on command line" 1>&2
 echo "$USAGE" 1>&2
 exit 1
else
 if [ -e "$script_name" ]
 then
  # source this script, defining array $all_jobs
  . $script_name
 else
  echo "Error: (run_jobs.sh) file `pwd`/$script_name does not exist or cannot be read" 1>&2
  echo "$USAGE" 1>&2
  exit 1
 fi
fi

# globals derived from script_name
basen=`echo "$script_name" | sed -e 's/.sh//'`
basen_override=`echo "$override_file_name" | sed -e 's/.sh//'`
if [ ! -z $basen_override ]; then basen=$basen_override; fi

throttle_file=$JOB_STATE_DIR/${basen}.throttle
jobs_file=$JOB_STATE_DIR/${basen}.jobs_run
pid_file=$JOB_STATE_DIR/${basen}.PID
stop_file=$JOB_STATE_DIR/${basen}.STOP
verbose=1

query () {

 local index=0
 local jobs_run=0
 local num_jobs=0

 # check to see if we are already running, and if so what is the state
 if [ -e $pid_file ]
 then
  ps_stat="ZZ"
  ps_stat=`ps -flp $(cat $pid_file) | tail +2 | awk '{ print $2 }'`
  if [ "$ps_stat" != "S" -a "$ps_stat" != "W" -a "$ps_stat" != "R" ]
  then
   echo "Warning: ($script_name) script apparently exited before completing, or is in a stopped state"
  else
   echo "Info: ($script_name) script is running see: $pid_file for PID"
  fi
 fi

 echo ""
 echo "Info: ($script_name) Status of jobs run by $script_name at: " `date`


 # look to see if the file was stopped by stop file
 if [ -e $stop_file ]
 then
  echo "Warning: ($script_name) file $stop_file exists, script has been paused."
 fi

 # look for the jobs_file, if it exists read it and display our progress
 if [ -e $jobs_file ]
    then
  jobs_run=`cat $jobs_file`

  index=0
  num_jobs=${#all_jobs[@]}

  echo ' Job Number   Status Command'
        echo '------------------------------'

  while [ "$index" -lt "$num_jobs" ]
  do
    if [ "$index" -le "$jobs_run" ]
    then
     echo " COMPLETED   ($index): " ${all_jobs[$index]}
    else
     echo " not started ($index): " ${all_jobs[$index]}
    fi

    let "index = $index + 1"
  done
 else
  echo "Info: ($script_name) script not yet started"
 fi
}

#
# Main
#

# run query, if requested
if [ ! -z "$run_query" ]
then
    query
    exit
fi

#
# exit if we are already running
if [ -e $pid_file ]
then
 ps_stat="ZZ"
 ps_stat=`ps -flp $(cat $pid_file) | tail +2 | awk '{ print $2 }'`
 if [ "$ps_stat" != "S" -a "$ps_stat" != "W" -a "$ps_stat" != "R" ]
 then
  echo "Warning: ($script_name) script apparently exited before completing, or is in a stopped state"
 else
  echo "Info: ($script_name) script is running see: $pid_file for PID"
  exit 1
 fi
fi

# save our process ID so we can tell if we are already running or
# if last run did not finish cleanly

echo $$ > $pid_file

# get start of job
timestamp=`/bin/date +%Y%m%d-%H%M%S`
export timestamp

# run jobs not yet run

# get the number of the job that was last run successfully,
# if it exists
jobs_run=-1
if [ -e $jobs_file ]
then
 jobs_run=`cat $jobs_file`
fi

index=0
num_jobs=${#all_jobs[@]}

# set batch_start and batch_end to a default if not specified on command line
if [ -z "$batch_end" ]
then
 let "stop_step = $num_jobs + 1"
else
 let "stop_step = $batch_end"
fi

if [ -z "$batch_start" ]
then
 batch_start=0
fi


while [ "$index" -lt "$num_jobs" ]
do

  # stop if signaled to
  if [ -e $stop_file ]
  then
   echo "Info: ($script_name) STOP signaled, file $stop_file exists"
   exit 1
  fi

  # stop we have already finished the last job specified
  if [ "$index" -gt "$stop_step" ]
  then
   echo "Info: ($script_name) script stopped at specified step $stop_step at: "`date`
   exit
  fi

  # this is the first step, set jobs_file to init step
  if [ ! -e $jobs_file ]
  then
   echo "-1" > $jobs_file
  fi
    
  if [ "$index" -le "$jobs_run" -o "$index" -lt "$batch_start" ]
  then
   echo "Info: ($script_name) ...skipping ($index): " ${all_jobs[$index]}
  else
   echo "Info: ($script_name) Starting    ($index): " ${all_jobs[$index]}
   ${all_jobs[$index]}

   # check the status returned
   if [ $? -gt 0 ]
   then
    echo "   "  ${all_jobs[$index]} " returned error, exiting"
          error_msg " "  ${all_jobs[$index]} " returned error"
    exit 1
   else
    # mark this job as done
    echo "$index" > $jobs_file
   fi
  fi

  let "index = $index + 1"

done

# If we got here all jobs have completed, so lets clean up
# remove the jobs file only if the "end" step was not specified
if [ -z "$batch_end" ]
then
 rm -f $jobs_file
fi

echo "Info: ($script_name) All jobs completed successfully at: "`date`

# remove the PID file so we know script is done and finished cleanly
rm -f $pid_file

exit
