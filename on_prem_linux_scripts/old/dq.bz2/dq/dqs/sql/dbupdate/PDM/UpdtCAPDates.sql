SET pause OFF
SET feedback ON
SET TIME ON
SET timing ON

WHENEVER SQLERROR EXIT failure ROLLBACK

DECLARE
   CURSOR c1 IS
	SELECT pqprov.pq_prov_seq as pqseq, tracking.CAP_DUE_DT as capduedt
	FROM 	
	   pd_ufr_tracking tracking,
	   (select prov.*, 
	           const.cur_fy_year as fy_year, 
	           pq.* 
	    from pd_pos_prov prov, 
	         pq_pos_prov pq, 
	         pq_constants const
	    where pq.pdm_provider_seq = prov.pdm_provider_seq and 
	          pq.pq_year = const.pq_year) pqprov
    WHERE 
        pqprov.fy_year = tracking.ufr_filing_period and
        pqprov.ciw_tin_fein = tracking.ciw_tin_fein and
        tracking.cap_due_dt != to_date('01/01/1900','MM/DD/YYYY');
BEGIN
   FOR ufr IN c1 LOOP  -- process each row one at a time
   BEGIN
         INSERT INTO PQ_CPA (PQ_PROV_SEQ, CAP_STATUS, DT_CAP__DUE_OSD)
         VALUES (ufr.pqseq, 'N/A', ufr.capduedt);
         EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN   -- account already exists
        UPDATE pq_cpa SET
         DT_CAP__DUE_OSD = ufr.capduedt
        WHERE
         pq_prov_seq = ufr.pqseq;
   END;
   END LOOP;
   
END;
/